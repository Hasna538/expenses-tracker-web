import React, { useState } from "react";

function ExpenseTracker({ expenses, setExpenses, userId }) {
  const [description, setDescription] = useState("");
  const [amount, setAmount] = useState("");

  // ✅ Add new expense
  const handleAdd = (e) => {
    e.preventDefault();
    if (!description || !amount) return;

    const newExpense = {
      id: Date.now(), // unique id
      description,
      amount: parseFloat(amount),
    };

    setExpenses([...expenses, newExpense]); // Dashboard state update
    setDescription("");
    setAmount("");
  };

  // ✅ Delete expense
  const handleDelete = (id) => {
    setExpenses(expenses.filter((exp) => exp.id !== id));
  };

  return (
    <div style={{ marginBottom: "30px" }}>
      <form onSubmit={handleAdd} className="expense-form">
        <input
          type="text"
          placeholder="Enter description"
          value={description}
          onChange={(e) => setDescription(e.target.value)}
        />
        <input
          type="number"
          placeholder="Enter amount"
          value={amount}
          onChange={(e) => setAmount(e.target.value)}
        />
        <button type="submit">Add Expense</button>
      </form>

      <ul>
        {expenses.map((exp) => (
          <li key={exp.id}>
            {exp.description} - Rs {exp.amount}
            <button onClick={() => handleDelete(exp.id)}>Delete</button>
          </li>
        ))}
      </ul>
    </div>
  );
}

export default ExpenseTracker;
