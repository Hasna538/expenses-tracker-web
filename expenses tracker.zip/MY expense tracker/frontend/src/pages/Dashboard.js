import React, { useState } from 'react';
import { useParams } from 'react-router-dom';
import ExpenseTracker from '../components/ExpenseTracker';
import { Bar } from "react-chartjs-2";
import {
  Chart as ChartJS,
  CategoryScale,
  LinearScale,
  BarElement,
  Tooltip,
  Legend,
} from "chart.js";

ChartJS.register(
  CategoryScale,
  LinearScale,
  BarElement,
  Tooltip,
  Legend
);

function Dashboard() {
  const { userId } = useParams();

  // ✅ Add expenses state
  const [expenses, setExpenses] = useState([]);

  // ✅ Chart data from expenses
  const chartData = {
    labels: expenses.map(exp => exp.description),
    datasets: [
      {
        label: "Amount (Rs)",
        data: expenses.map(exp => exp.amount),
        backgroundColor: "rgba(54, 162, 235, 0.6)", // blue
        borderColor: "rgba(54, 162, 235, 1)",
        borderWidth: 1,
      },
    ],
  };

  const chartOptions = {
    responsive: true,
    plugins: {
      legend: {
        position: "top",
        labels: {
          color: "#ffffff" // white labels for black background
        }
      },
      tooltip: {
        enabled: true
      }
    },
    scales: {
      x: {
        ticks: { color: "#ffffff" },
        grid: { color: "rgba(255,255,255,0.1)" }
      },
      y: {
        ticks: { color: "#ffffff" },
        grid: { color: "rgba(255,255,255,0.1)" }
      }
    }
  };

  return (
    <div className="container" style={{ backgroundColor: "#121212", color: "#ffffff", padding: "20px", borderRadius: "8px" }}>
      <h1 style={{ textAlign: "center", marginBottom: "20px" }}>Dashboard</h1>

      {/* Expense Tracker */}
      <ExpenseTracker expenses={expenses} setExpenses={setExpenses} userId={userId} />

      {/* Expense Chart */}
      <div style={{ marginTop: "40px" }}>
        <h2 style={{ textAlign: "center" }}>Expenses Chart</h2>
        <Bar data={chartData} options={chartOptions} />
      </div>
    </div>
  );
}

export default Dashboard;
